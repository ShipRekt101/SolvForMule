Thank You for downloading my programming group "Formula Solver"
I appreciate it!
//
Made for the TI-84 Plus, TI-84 Plus SE
//*I cannot guarantee that it will work on any previous or future models of the TI-84 Plus
Programmed in: BASIC
Version 1.0
//
//
By: Shishir Lohar
For Any Questions or Suggestions
Comment under the project description
//
//*Notice; This material is open-source as long as you do not use the same name and give me credit
//
Overview-
This is a tool on your TI-84 calculator that solves math problems for you. For example, if you wanted to find the surface area
of a Rectangular Prisim, instead of using the whole formula and typing it out, you can go to the program and type in the measures
like length, width and height, and it will give you the answer. I have provided screenshots of the programs in action and you can 
check them out.
//
//
//
Programs included:
-Coordinate Midpoint and Distance finder; CDGEOFOR in calculator
-Circle Area; CIRCAREA in calculator
-Circumference; CIRCUMFR in calculator
-Linear Equation Checker; EQUCHECK in calculator
-Pythagorean Theorum; PYGNTHRM in calculator
-Volume finder of a Cylinder, Pyramid, Cone, and Sphere; SHAPEPCK in calculator
-Simple Interest Finder; SIMPINTR in calculator
-Surface area formula for any prism; SURFAREA in calculator
-Triangle area; TRIAREA in calculator
-Volume of any prism; VOLMRECT in calculator
-Volume of a sphere; VOLSPHRE in calculator
//
//
//
Steps to install-
To install Formula Solver:
1. You need to ungroup the group called "Formula Programs", (It will show up as FRMPRGMS)
2. Then Select the program you would like to run 						
//*The programs included will be under diiferent names and they are listed above in the programs included section for your
convenience.
3. Enjoy!

//**Notice;  I will be posting further updates in the coming months, so feel free to report
any issues or provide suggestions  